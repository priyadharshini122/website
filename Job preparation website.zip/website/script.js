document.getElementById("submitbutton").addEventListener("click", function() {
  // This code will execute when the button is clicked
  window.location.href = "homepage.html"; // Replace with the path to your next page
});

